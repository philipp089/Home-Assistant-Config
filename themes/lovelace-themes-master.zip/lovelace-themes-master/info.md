# Google Home Theme

Following this request, I've been workin on 2 themes to match the design of "google home":
https://community.home-assistant.io/t/why-can-t-we-have-ui-like-these-quite-inspiring/99740?u=naofireblade

Hope you like it!

## Light
![Light](https://raw.githubusercontent.com/liri/lovelace-themes/master/screenshots/Google%20-%20Light/1.JPG)
![Light](https://raw.githubusercontent.com/liri/lovelace-themes/master/screenshots/Google%20-%20Light/2.JPG)
![Light](https://raw.githubusercontent.com/liri/lovelace-themes/master/screenshots/Google%20-%20Light/3.JPG)
![Light](https://raw.githubusercontent.com/liri/lovelace-themes/master/screenshots/Google%20-%20Light/4.JPG)
![Light](https://raw.githubusercontent.com/liri/lovelace-themes/master/screenshots/Google%20-%20Light/5.JPG)
![Light](https://raw.githubusercontent.com/liri/lovelace-themes/master/screenshots/Google%20-%20Light/6.png)
![Light](https://raw.githubusercontent.com/liri/lovelace-themes/master/screenshots/Google%20-%20Light/7.png)
![Light](https://raw.githubusercontent.com/liri/lovelace-themes/master/screenshots/Google%20-%20Light/8.png)
![Light](https://raw.githubusercontent.com/liri/lovelace-themes/master/screenshots/Google%20-%20Light/9.png)
![Light](https://raw.githubusercontent.com/liri/lovelace-themes/master/screenshots/Google%20-%20Light/10.png)

## Dark
![Dark](https://raw.githubusercontent.com/liri/lovelace-themes/master/screenshots/Google%20-%20Dark/1.JPG)
![Dark](https://raw.githubusercontent.com/liri/lovelace-themes/master/screenshots/Google%20-%20Dark/2.JPG)
![Dark](https://raw.githubusercontent.com/liri/lovelace-themes/master/screenshots/Google%20-%20Dark/3.JPG)
![Dark](https://raw.githubusercontent.com/liri/lovelace-themes/master/screenshots/Google%20-%20Dark/4.JPG)
![Dark](https://raw.githubusercontent.com/liri/lovelace-themes/master/screenshots/Google%20-%20Dark/5.JPG)
![Dark](https://raw.githubusercontent.com/liri/lovelace-themes/master/screenshots/Google%20-%20Dark/6.png)
![Dark](https://raw.githubusercontent.com/liri/lovelace-themes/master/screenshots/Google%20-%20Dark/7.png)
![Dark](https://raw.githubusercontent.com/liri/lovelace-themes/master/screenshots/Google%20-%20Dark/8.png)
![Dark](https://raw.githubusercontent.com/liri/lovelace-themes/master/screenshots/Google%20-%20Dark/9.png)
![Dark](https://raw.githubusercontent.com/liri/lovelace-themes/master/screenshots/Google%20-%20Dark/10.png)

Font I used for my HA dashboard: Open Sans & Rubik (for hebrew)
